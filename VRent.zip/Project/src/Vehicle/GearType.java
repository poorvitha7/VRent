package Vehicle;
public enum GearType{
    Auto,
    Manual,
}