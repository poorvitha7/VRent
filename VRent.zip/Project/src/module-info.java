/**
 * 
 */
/**
 * @author suhas
 *
 */
module Project {
	requires java.sql;
}